export const FormStates = Object.freeze({
  LOADING: "loading",
  SUCCESS: "success",
});
